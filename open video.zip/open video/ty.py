import os

os.startfile("C:\\Users\\Алиска\\Desktop\\open video\\rick.mp3")

